<?php 

$email_adm = 'odnangame@gmail.com';
$url_site = 'http://localhost/delivery/';


//DADOS PARA CONEXÃO COM BD LOCAL
$banco = 'delivery';
$host = 'localhost';
$usuario = 'root';
$senha = '';

//CONFIGURAÇÕES PARA PAGINAÇÃO DE ITENS NO PAINEL
//Valor padrão para as paginações
$itens_por_pagina = 5;

//valor que o usuario pode alterar para mostrar a paginação
$itens_por_pagina_1 = 5;
$itens_por_pagina_2 = 10;
$itens_por_pagina_3 = 20;

 ?>